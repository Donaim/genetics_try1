﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testp
{
    class test_entry
    {
        static void Main(string[] ager)
        {
            new Testp.First().test_field_ctrl1();
        }
    }
}
