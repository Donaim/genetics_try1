﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

using core;
using visualizer;
using genetics_try1;

using System.Windows.Forms;

namespace Testp
{
    [TestClass]
    public class Custom
    {
        [TestMethod]
        public void test_get_surrounding()
        {
            //Console.WriteLine("START");
            //U.InputSize = MyAgent.SurroundingLen *NatureObject.IDSpaceCount + MyAgent.IntrospectLen + ActionsBase.UncertainEvent.IDSpaceLenght;
            //var lm = new MyLearnManager();

            //for(int i = 0; i < 1000; i++) { cycle(); }
            //void cycle()
            //{
            //    var field = new MyField(47, 23);

            //    var agents = new List<MyAgent>();
            //    for (int i = 0; i < 20; i++) { My_FoodObj.SpawnRandomNormal(field); }
            //    for (int i = 0; i < 10; i++) { agents.Add((MyAgent)lm.CreateNew(field)); }

            //    foreach (var a in agents)
            //    {
            //        a.SerializeSurrounding(new U.DoubleStream(U.InputSize));
            //    }
            //}
        }

        [TestMethod]
        public void test_walking()
        {
            //Console.WriteLine("START");
            //U.InputSize = MyAgent.SurroundingLen *NatureObject.IDSpaceCount + MyAgent.IntrospectLen + ActionsBase.UncertainEvent.IDSpaceLenght;

            //var field = new MyField(47, 23);
            //var ctrl = new FieldControl(field);

            //var lm = new MyLearnManager();

            //var agents = new List<MyAgent>();
            //for (int i = 0; i < 20; i++) { My_FoodObj.SpawnRandomNormal(field); }
            //for (int i = 0; i < 10; i++) { agents.Add((MyAgent)lm.CreateNew(field)); }

            //foreach (var a in agents)
            //{
            //    a.Do();
            //}
        }
    }
}
